# Recursos de Matemáticas (5º a 9º)

Este repositorio contiene carpetas organizadas por grado para subir material educativo.

## Estructura
- 5to
- 6to
- 7mo
- 8vo
- 9no

Agrega tus archivos en la carpeta correspondiente.
